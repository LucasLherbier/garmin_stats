"""
Random User-Agent
Copyright: 2022-2026 Ekin Karadeniz (github.com/iamdual)
License: Apache License 2.0 
"""
import random
from typing import List

from ..filterer import Filterer
from ..version import Version, ChromiumVersion
from ...options import Options

# https://chromereleases.googleblog.com/search/label/Stable%20updates
VERSIONS: List[ChromiumVersion] = [
    ChromiumVersion(Version(major=100, minor=0, build=4896, patch=(0, 255))),
    ChromiumVersion(Version(major=101, minor=0, build=4951, patch=(0, 255))),
    ChromiumVersion(Version(major=102, minor=0, build=5005, patch=(0, 255))),
    ChromiumVersion(Version(major=103, minor=0, build=5060, patch=(0, 255))),
    ChromiumVersion(Version(major=104, minor=0, build=5112, patch=(0, 255))),
    ChromiumVersion(Version(major=105, minor=0, build=5195, patch=(0, 255))),
    ChromiumVersion(Version(major=106, minor=0, build=5249, patch=(0, 255))),
    ChromiumVersion(Version(major=107, minor=0, build=5304, patch=(0, 255))),
    ChromiumVersion(Version(major=108, minor=0, build=5359, patch=(0, 255))),
    ChromiumVersion(Version(major=109, minor=0, build=5414, patch=(0, 255))),
    ChromiumVersion(Version(major=110, minor=0, build=5481, patch=(0, 255))),
    ChromiumVersion(Version(major=111, minor=0, build=5563, patch=(0, 255))),
    ChromiumVersion(Version(major=112, minor=0, build=5615, patch=(0, 255))),
    ChromiumVersion(Version(major=114, minor=0, build=5735, patch=(0, 255))),
    ChromiumVersion(Version(major=115, minor=0, build=5790, patch=(0, 255))),
    ChromiumVersion(Version(major=116, minor=0, build=5845, patch=(0, 255))),
    ChromiumVersion(Version(major=117, minor=0, build=5938, patch=(0, 255))),
    ChromiumVersion(Version(major=118, minor=0, build=5993, patch=(0, 255))),
    ChromiumVersion(Version(major=119, minor=0, build=6045, patch=(0, 255))),
    ChromiumVersion(Version(major=120, minor=0, build=6099, patch=(0, 255))),
    ChromiumVersion(Version(major=121, minor=0, build=6167, patch=(0, 255))),
    ChromiumVersion(Version(major=122, minor=0, build=6261, patch=(0, 255))),
    ChromiumVersion(Version(major=123, minor=0, build=6312, patch=(0, 255))),
    ChromiumVersion(Version(major=124, minor=0, build=6367, patch=(0, 255))),
    ChromiumVersion(Version(major=125, minor=0, build=6422, patch=(0, 255))),
    ChromiumVersion(Version(major=126, minor=0, build=6478, patch=(0, 255))),
    ChromiumVersion(Version(major=127, minor=0, build=6533, patch=(0, 255))),
    ChromiumVersion(Version(major=128, minor=0, build=6613, patch=(0, 255))),
    ChromiumVersion(Version(major=129, minor=0, build=6668, patch=(0, 255))),
    ChromiumVersion(Version(major=130, minor=0, build=6723, patch=(0, 255))),
    ChromiumVersion(Version(major=131, minor=0, build=6778, patch=(0, 255))),
    ChromiumVersion(Version(major=132, minor=0, build=6834, patch=(0, 255))),
    ChromiumVersion(Version(major=133, minor=0, build=6943, patch=(0, 255))),
    ChromiumVersion(Version(major=134, minor=0, build=6998, patch=(0, 255))),
    ChromiumVersion(Version(major=135, minor=0, build=7049, patch=(0, 255))),
    ChromiumVersion(Version(major=136, minor=0, build=7103, patch=(0, 255))),
    ChromiumVersion(Version(major=137, minor=0, build=7151, patch=(0, 255))),
    ChromiumVersion(Version(major=138, minor=0, build=7204, patch=(0, 255))),
    ChromiumVersion(Version(major=139, minor=0, build=7258, patch=(0, 255))),
    ChromiumVersion(Version(major=140, minor=0, build=7339, patch=(0, 255))),
    ChromiumVersion(Version(major=141, minor=0, build=7390, patch=(0, 255))),
    ChromiumVersion(Version(major=142, minor=0, build=7444, patch=(0, 255))),
    ChromiumVersion(Version(major=143, minor=0, build=7499, patch=(0, 255))),
    ChromiumVersion(Version(major=144, minor=0, build=7559, patch=(0, 255))),
    ChromiumVersion(Version(major=145, minor=0, build=7632, patch=(0, 255))),
    ChromiumVersion(Version(major=146, minor=0, build=7680, patch=(0, 255))),
    ChromiumVersion(Version(major=147, minor=0, build=7727, patch=(0, 255))),
    ChromiumVersion(Version(major=148, minor=0, build=7778, patch=(0, 255))),
    ChromiumVersion(Version(major=149, minor=0, build=7827, patch=(0, 255))),
    ChromiumVersion(Version(major=150, minor=0, build=7871, patch=(0, 255))),
    ChromiumVersion(Version(major=151, minor=0, build=7922, patch=(0, 255))),
    ChromiumVersion(Version(major=152, minor=0, build=7977, patch=(0, 255))),
    ChromiumVersion(Version(major=153, minor=0, build=8010, patch=(0, 255))),
    ChromiumVersion(Version(major=154, minor=0, build=8037, patch=(0, 255))),
]


def get_version(options: Options) -> ChromiumVersion:
    filterer = Filterer(VERSIONS, 'chrome', options)

    return random.choice(filterer.versions)
